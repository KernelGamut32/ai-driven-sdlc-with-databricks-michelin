"""Code tests for the business rules in plain Python (o2i.rules).

These tests need Python and nothing else: no Spark, no connection, no installed package.
Run them with:  python tools/run_tests.py     or:  python -m unittest

Every expected value comes from the business contract (docs/business_contract.md) or from a hand
calculation. No expected value was produced by the code under test.
"""
import unittest
from decimal import Decimal as D

from o2i import config, rules


class StatusTests(unittest.TestCase):
    """Rule R2: the status is compared trimmed and in upper case."""

    def test_normalize_status_trims_and_uppercases(self):
        cases = [("POSTED", "POSTED"), ("Posted ", "POSTED"), (" posted", "POSTED"), ("draft", "DRAFT"),
                 ("   ", ""), (None, None)]
        for raw, expected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(rules.normalize_status(raw), expected)

    def test_posted_in_any_case_and_with_spaces_is_posted(self):
        for raw in ("POSTED", "Posted", "posted", "POSTED ", " POSTED", "Posted "):
            with self.subTest(raw=raw):
                self.assertEqual(rules.classify_status(raw), "POSTED")

    def test_draft_and_cancelled_are_not_posted(self):
        for raw in ("DRAFT", "draft", "Draft ", "CANCELLED", "Cancelled", "cancelled"):
            with self.subTest(raw=raw):
                self.assertEqual(rules.classify_status(raw), "NOT_POSTED")

    def test_any_other_value_is_unexpected(self):
        for raw in ("PENDING", "BOOKED", "ON HOLD", "PST", "POSTED X", "", "   ", None):
            with self.subTest(raw=raw):
                self.assertEqual(rules.classify_status(raw), "UNEXPECTED")


class DateTests(unittest.TestCase):
    """Rule R4: exactly yyyy-MM-dd, and a real calendar date."""

    def test_valid_dates(self):
        for text in ("2026-04-02", "2025-07-01", "2024-02-29"):
            with self.subTest(text=text):
                self.assertTrue(rules.is_valid_iso_date(text))

    def test_invalid_dates(self):
        for text in ("2026-02-30", "2025-13-05", "2026-04-31", "2025-02-29", "31/03/2026", "20260412",
                     "2026-3-7", " 2026-04-02", "2026-04-02 ", "", None):
            with self.subTest(text=text):
                self.assertFalse(rules.is_valid_iso_date(text))


class AmountTests(unittest.TestCase):
    """Rule R7 and the derived amounts: decimal arithmetic, rounding half up, signs preserved."""

    def test_net_amount_is_quantity_times_price_rounded_half_up(self):
        cases = [(D("4"), D("91.7875"), D("367.15")),
                 (D("2.5"), D("12.2500"), D("30.63")),          # 30.625 is a tie
                 (D("0.333"), D("29.9900"), D("9.99")),         # 9.98667
                 (D("-4"), D("91.7875"), D("-367.15"))]         # a credit keeps its sign
        for quantity, price, expected in cases:
            with self.subTest(quantity=quantity, price=price):
                self.assertEqual(rules.expected_net_amount(quantity, price), expected)

    def test_amount_matches(self):
        self.assertTrue(rules.amount_matches(D("4"), D("91.7875"), D("367.15")))
        self.assertTrue(rules.amount_matches(D("-2"), D("91.7900"), D("-183.58")))
        self.assertFalse(rules.amount_matches(D("-2"), D("91.7900"), D("183.58")))      # sign lost at the source
        self.assertFalse(rules.amount_matches(D("4"), D("91.7875"), D("3671.50")))      # ten times too large

    def test_a_missing_value_never_matches(self):
        self.assertFalse(rules.amount_matches(None, D("91.7875"), D("367.15")))
        self.assertFalse(rules.amount_matches(D("4"), None, D("367.15")))
        self.assertFalse(rules.amount_matches(D("4"), D("91.7875"), None))

    def test_tax_without_a_rate_is_zero(self):
        self.assertEqual(rules.tax_amount(D("793.04"), None), D("0.00"))
        self.assertEqual(rules.gross_amount(D("793.04"), None), D("793.04"))

    def test_a_rate_of_zero_is_a_rate(self):
        self.assertEqual(rules.gross_amount(D("4510.70"), D("0.0000")), D("4510.70"))

    def test_gross_amount_of_a_credit_keeps_its_sign(self):
        self.assertEqual(rules.gross_amount(D("-367.15"), D("0.2000")), D("-440.58"))

    def test_tax_rounds_half_up_on_a_tie(self):
        """LAB 3, TEST 1. Write this test.

        The contract says: rounding is half up to two decimals. Choose a net amount and a tax rate
        whose tax ends exactly on half a cent, calculate the expected tax by hand, and assert it.
        Take the numbers from the contract or from the fixture workbook, not from the code.
        """
        self.skipTest("Lab 3, test 1 is not written yet")

    def test_tax_of_a_credit_rounds_away_from_zero_on_a_tie(self):
        """LAB 3, TEST 2. Write this test.

        The same tie for a credit line: a negative net amount. Half up means away from zero.
        Assert the tax and the gross amount.
        """
        self.skipTest("Lab 3, test 2 is not written yet")

    def test_amounts_have_two_decimals(self):
        for value in (rules.tax_amount(D("367.15"), D("0.2000")), rules.gross_amount(D("367.15"), None),
                      rules.expected_net_amount(D("1200"), D("68.1850"))):
            with self.subTest(value=value):
                self.assertEqual(value.as_tuple().exponent, -2)

    def test_money_is_never_a_float(self):
        with self.assertRaises(TypeError):
            rules.gross_amount(367.15, D("0.2000"))
        with self.assertRaises(TypeError):
            rules.tax_amount(D("367.15"), 0.2)
        with self.assertRaises(TypeError):
            rules.expected_net_amount(4, 91.7875)


def _delivery(raw_row_id, quantity="4", batch="LB-20260403"):
    return {"RawRowID": raw_row_id, "InvoiceID": "INV-1", "LineNumber": 1, "Quantity": D(quantity),
            "NetAmount": D(quantity) * D("10.00"), "LoadBatchID": batch, "IngestedAt": "2026-04-03 02:10:00"}


class DuplicateTests(unittest.TestCase):
    """Rule R3: exact replays are not conflicting duplicates."""

    def test_a_single_delivery_is_unique(self):
        self.assertEqual(rules.duplicate_classes([_delivery("F0001")]), {"F0001": "UNIQUE"})

    def test_identical_deliveries_keep_the_lowest_raw_row_id(self):
        rows = [_delivery("F0009", batch="LB-20260405"), _delivery("F0002"), _delivery("F0005", batch="LB-20260404")]
        self.assertEqual(rules.duplicate_classes(rows),
                         {"F0002": "REPLAY_FIRST", "F0005": "REPLAY_EXTRA", "F0009": "REPLAY_EXTRA"})

    def test_different_content_holds_every_delivery(self):
        rows = [_delivery("F0001", quantity="4"), _delivery("F0002", quantity="6")]
        self.assertEqual(rules.duplicate_classes(rows), {"F0001": "CONFLICT", "F0002": "CONFLICT"})

    def test_two_identical_and_one_different_are_all_held(self):
        rows = [_delivery("F0001"), _delivery("F0002"), _delivery("F0003", quantity="2")]
        self.assertEqual(set(rules.duplicate_classes(rows).values()), {"CONFLICT"})

    def test_technical_columns_do_not_make_a_conflict(self):
        first, second = _delivery("F0001"), _delivery("F0002", batch="LB-20260409")
        second["IngestedAt"] = "2026-04-09 02:10:00"
        self.assertEqual(rules.business_content(first), rules.business_content(second))


def decide(**facts):
    """decide_disposition for a line that passes every rule, with the given facts changed."""
    clean = dict(missing_required=False, status_class="POSTED", duplicate_class="UNIQUE", date_valid=True,
                 customer_matches=1, product_matches=1, amount_ok=True)
    clean.update(facts)
    return rules.decide_disposition(**clean)


class DecisionTests(unittest.TestCase):
    """One outcome for each delivered row, and the first failing rule decides."""

    def test_a_line_that_passes_every_rule_is_accepted(self):
        self.assertEqual(decide(), ("ACCEPTED", None))
        self.assertEqual(decide(duplicate_class="REPLAY_FIRST"), ("ACCEPTED", None))

    def test_each_rule_has_its_reason(self):
        cases = [(dict(missing_required=True), ("QUARANTINED", "MISSING_REQUIRED_FIELD")),
                 (dict(status_class="NOT_POSTED"), ("EXCLUDED", "NOT_POSTED")),
                 (dict(status_class="UNEXPECTED"), ("QUARANTINED", "UNEXPECTED_STATUS")),
                 (dict(duplicate_class="CONFLICT"), ("QUARANTINED", "CONFLICTING_DUPLICATE")),
                 (dict(duplicate_class="REPLAY_EXTRA"), ("EXCLUDED", "EXACT_REPLAY")),
                 (dict(date_valid=False), ("QUARANTINED", "INVALID_DATE")),
                 (dict(customer_matches=0), ("QUARANTINED", "UNKNOWN_CUSTOMER")),
                 (dict(customer_matches=2), ("QUARANTINED", "AMBIGUOUS_CUSTOMER")),
                 (dict(product_matches=0), ("QUARANTINED", "UNKNOWN_PRODUCT")),
                 (dict(product_matches=3), ("QUARANTINED", "AMBIGUOUS_PRODUCT")),
                 (dict(amount_ok=False), ("QUARANTINED", "AMOUNT_MISMATCH"))]
        for facts, expected in cases:
            with self.subTest(facts=facts):
                self.assertEqual(decide(**facts), expected)

    def test_the_first_failing_rule_decides(self):
        cases = [(dict(missing_required=True, status_class="NOT_POSTED"), "MISSING_REQUIRED_FIELD"),   # R1 before R2
                 (dict(status_class="NOT_POSTED", customer_matches=0), "NOT_POSTED"),                  # R2 before R5
                 (dict(duplicate_class="CONFLICT", date_valid=False), "CONFLICTING_DUPLICATE"),        # R3 before R4
                 (dict(date_valid=False, customer_matches=0), "INVALID_DATE"),                         # R4 before R5
                 (dict(customer_matches=0, product_matches=0), "UNKNOWN_CUSTOMER"),                    # R5 before R6
                 (dict(product_matches=0, amount_ok=False), "UNKNOWN_PRODUCT")]                        # R6 before R7
        for facts, expected in cases:
            with self.subTest(facts=facts):
                self.assertEqual(decide(**facts)[1], expected)

    def test_a_valid_credit_is_decided_like_any_other_line(self):
        # A credit is a line with a negative quantity whose amount matches (rule R7). Nothing else is special.
        self.assertTrue(rules.amount_matches(D("-4"), D("91.7875"), D("-367.15")))
        self.assertEqual(decide(amount_ok=True), ("ACCEPTED", None))

    def test_every_reason_is_a_reason_of_the_contract(self):
        produced = {decide(**facts)[1] for facts in (
            dict(missing_required=True), dict(status_class="NOT_POSTED"), dict(status_class="UNEXPECTED"),
            dict(duplicate_class="CONFLICT"), dict(duplicate_class="REPLAY_EXTRA"), dict(date_valid=False),
            dict(customer_matches=0), dict(customer_matches=2), dict(product_matches=0), dict(product_matches=2),
            dict(amount_ok=False))}
        self.assertEqual(produced, set(config.REASONS))


if __name__ == "__main__":
    unittest.main()
