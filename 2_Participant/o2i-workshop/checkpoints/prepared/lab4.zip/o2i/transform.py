"""Spark transformation for the order-to-invoice (O2I) accepted dataset.

Every delivered invoice line gets exactly one outcome. The steps follow the business contract
(docs/business_contract.md) rule by rule:

    read_inputs -> add_facts -> decide -> build_outputs -> write_outputs

add_facts computes one fact for each rule and never filters, drops, or multiplies a row.
decide turns the facts into one Disposition and one ReasonCode, in the order of the contract.
The same decision exists in plain Python (o2i.rules.decide_disposition). The data-quality check
spec_agreement proves on the fixture that both agree.
"""
from __future__ import annotations

from typing import Dict, Iterable, NamedTuple

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F

import lab_config
from o2i import config
from o2i.session import table_name


class Outputs(NamedTuple):
    accepted: DataFrame       # one row for each accepted invoice line, enriched, in the contract schema
    exceptions: DataFrame     # every other delivered row, as delivered, with Disposition and ReasonCode


def read_inputs(spark, dataset: str) -> Dict[str, DataFrame]:
    """Read the four input tables of a dataset: invoice_lines, customers, products, orders."""
    tables = config.DATASET_TABLES[dataset]
    return {name: spark.table(table_name(lab_config.INPUT_SCHEMA, tables[name]))
            for name in ("invoice_lines", "customers", "products", "orders")}


def add_facts(lines: DataFrame, customers: DataFrame, products: DataFrame, orders: DataFrame) -> DataFrame:
    """Return every delivered row with one fact column (f_...) for each rule of the contract."""
    types = dict(lines.dtypes)

    # R1: a required field is missing when it is NULL, or text that is empty after trimming.
    missing = F.lit(False)
    for field in config.REQUIRED_FIELDS:
        blank = F.col(field).isNull()
        if types[field] == "string":
            blank = blank | (F.trim(F.col(field)) == "")
        missing = missing | blank

    # R2: the status is compared trimmed and in upper case. The delivered value stays as it is.
    status = F.upper(F.trim(F.col("Status")))
    status_class = (F.when(status == "POSTED", "POSTED")
                    .when(status.isin("DRAFT", "CANCELLED"), "NOT_POSTED")
                    .otherwise("UNEXPECTED"))

    facts = (lines
             .withColumn("f_missing_required", missing)
             .withColumn("f_status_class", status_class)
             .withColumn("f_candidate", (~F.col("f_missing_required")) & (F.col("f_status_class") == "POSTED")))

    # R3: deliveries of one InvoiceID and LineNumber, among the rows that passed R1 and R2.
    # Two deliveries are identical when every column except the technical ones is equal.
    content_columns = [c for c in lines.columns if c not in config.TECHNICAL_COLUMNS]
    content = F.sha2(F.concat_ws("\u001f", *[F.coalesce(F.col(c).cast("string"), F.lit("\u0000"))
                                             for c in content_columns]), 256)
    same_key = Window.partitionBy("f_candidate", *config.GRAIN)
    facts = (facts
             .withColumn("f_content", content)
             .withColumn("f_deliveries", F.count(F.lit(1)).over(same_key))
             .withColumn("f_conflict", F.min("f_content").over(same_key) != F.max("f_content").over(same_key))
             .withColumn("f_delivery_no", F.row_number().over(same_key.orderBy("RawRowID")))
             .withColumn("f_duplicate_class",
                         F.when(~F.col("f_candidate"), F.lit(None).cast("string"))
                          .when(F.col("f_deliveries") == 1, "UNIQUE")
                          .when(F.col("f_conflict"), "CONFLICT")
                          .when(F.col("f_delivery_no") == 1, "REPLAY_FIRST")
                          .otherwise("REPLAY_EXTRA")))

    # R4: exactly yyyy-MM-dd, and a real calendar date. try_cast returns NULL instead of an error.
    date_valid = (F.col("InvoiceDate").rlike("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
                  & F.expr("try_cast(InvoiceDate AS DATE)").isNotNull())
    facts = facts.withColumn("f_date_valid", F.coalesce(date_valid, F.lit(False)))

    # R5 and R6: how many master rows has the key? The count is joined, never the attributes,
    # so this step cannot lose a line and cannot multiply a line.
    customer_rows = customers.groupBy("CustomerID").agg(F.count(F.lit(1)).alias("f_customer_matches"))
    product_rows = products.groupBy("ProductID").agg(F.count(F.lit(1)).alias("f_product_matches"))
    facts = (facts
             .join(customer_rows, "CustomerID", "left")
             .join(product_rows, "ProductID", "left")
             .withColumn("f_customer_matches", F.coalesce(F.col("f_customer_matches"), F.lit(0)))
             .withColumn("f_product_matches", F.coalesce(F.col("f_product_matches"), F.lit(0))))

    # R7: the delivered NetAmount equals Quantity x UnitPrice, rounded half up. Signs are kept.
    amount_ok = F.col("NetAmount") == F.round(F.col("Quantity") * F.col("UnitPrice"), 2)
    facts = facts.withColumn("f_amount_ok", F.coalesce(amount_ok, F.lit(False)))

    # R8: the order reference is present and matches exactly one order line. Existence only.
    order_rows = (orders.select("OrderID", "OrderLineNumber").dropDuplicates()      # each order line once
                  .withColumn("f_order_matches", F.lit(1)))
    is_credit = F.coalesce(F.col("Quantity") < 0, F.lit(False))                     # a credit has no order line of its own
    order_ref_present = (F.col("OrderID").isNotNull() & (F.trim(F.col("OrderID")) != "")
                         & F.col("OrderLineNumber").isNotNull())
    facts = (facts
             .join(order_rows, ["OrderID", "OrderLineNumber"], "left")
             .withColumn("f_order_ref_present", is_credit | F.coalesce(order_ref_present, F.lit(False)))
             .withColumn("f_order_matches", F.when(is_credit, F.lit(1)).otherwise(F.coalesce(F.col("f_order_matches"), F.lit(0)))))
    return facts


def decide(facts: DataFrame) -> DataFrame:
    """Add ReasonCode and Disposition. The first rule that fails decides, in the order of the contract."""
    f = F.col
    reason = (F.when(f("f_missing_required"), "MISSING_REQUIRED_FIELD")            # R1
               .when(f("f_status_class") == "NOT_POSTED", "NOT_POSTED")            # R2
               .when(f("f_status_class") != "POSTED", "UNEXPECTED_STATUS")         # R2
               .when(f("f_duplicate_class") == "CONFLICT", "CONFLICTING_DUPLICATE")  # R3
               .when(f("f_duplicate_class") == "REPLAY_EXTRA", "EXACT_REPLAY")     # R3
               .when(~f("f_date_valid"), "INVALID_DATE")                           # R4
               .when(f("f_customer_matches") == 0, "UNKNOWN_CUSTOMER")             # R5
               .when(f("f_customer_matches") > 1, "AMBIGUOUS_CUSTOMER")            # R5
               .when(f("f_product_matches") == 0, "UNKNOWN_PRODUCT")               # R6
               .when(f("f_product_matches") > 1, "AMBIGUOUS_PRODUCT")              # R6
               .when(~f("f_order_ref_present"), "MISSING_ORDER_REF")               # R8
               .when(f("f_order_matches") == 0, "UNKNOWN_ORDER_REF")               # R8
               .when(f("f_order_matches") > 1, "AMBIGUOUS_ORDER_REF")              # R8
               .when(~f("f_amount_ok"), "AMOUNT_MISMATCH"))                        # R7
    disposition = (F.when(reason.isNull(), config.ACCEPTED)
                    .when(reason.isin(*config.EXCLUDED_REASONS), config.EXCLUDED)
                    .otherwise(config.QUARANTINED))
    return facts.withColumn("ReasonCode", reason).withColumn("Disposition", disposition)


def _in_schema(df: DataFrame, schema: Iterable) -> DataFrame:
    return df.select(*[F.col(name).cast(dtype).alias(name) for name, dtype in schema])


def build_outputs(spark, dataset: str) -> Outputs:
    """Apply the contract to one dataset and return the accepted lines and the exceptions."""
    inputs = read_inputs(spark, dataset)
    decided = decide(add_facts(inputs["invoice_lines"], inputs["customers"], inputs["products"], inputs["orders"]))

    # An accepted line has exactly one customer row and one product row (R5, R6),
    # so these joins cannot multiply or lose a line. The check unique_grain proves it on every run.
    customer_attributes = inputs["customers"].select("CustomerID", "CustomerName", "Segment", "Country", "Region")
    product_attributes = inputs["products"].select("ProductID", "ProductName", "ProductLine")
    # No tax rate means that no tax applies. Without coalesce, TaxAmount and GrossAmount would be NULL.
    tax = F.coalesce(F.round(F.col("NetAmount") * F.col("TaxRate"), 2), F.lit(0)).cast("decimal(18,2)")
    accepted = (decided.filter(F.col("Disposition") == config.ACCEPTED)
                .join(customer_attributes, "CustomerID", "left")
                .join(product_attributes, "ProductID", "left")
                .withColumn("InvoiceDate", F.expr("try_cast(InvoiceDate AS DATE)"))
                .withColumn("TaxAmount", tax)
                .withColumn("GrossAmount", F.col("NetAmount") + F.col("TaxAmount")))
    exceptions = decided.filter(F.col("Disposition") != config.ACCEPTED)
    return Outputs(_in_schema(accepted, config.ACCEPTED_SCHEMA), _in_schema(exceptions, config.EXCEPTIONS_SCHEMA))


def write_outputs(outputs: Outputs, schema: str, dataset: str) -> Dict[str, str]:
    """Write both outputs as tables <dataset>_accepted and <dataset>_exceptions. Returns their names."""
    names = {"accepted": table_name(schema, f"{dataset}_accepted"),
             "exceptions": table_name(schema, f"{dataset}_exceptions")}
    for key, df in (("accepted", outputs.accepted), ("exceptions", outputs.exceptions)):
        df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(names[key])
    return names


def outcome_counts(spark, names: Dict[str, str]) -> list:
    """Rows by outcome, read from the written tables: [(disposition, reason, rows), ...]."""
    accepted_rows = spark.table(names["accepted"]).count()
    rows = [(config.ACCEPTED, "", accepted_rows)]
    grouped = (spark.table(names["exceptions"]).groupBy("Disposition", "ReasonCode").count()
               .orderBy("Disposition", "ReasonCode").collect())
    rows += [(r["Disposition"], r["ReasonCode"], r["count"]) for r in grouped]
    return rows


def trace(spark, dataset: str, raw_row_ids: Iterable[str]) -> DataFrame:
    """Show the facts and the decision for chosen delivered rows. Use it to trace a failure to records."""
    inputs = read_inputs(spark, dataset)
    decided = decide(add_facts(inputs["invoice_lines"], inputs["customers"], inputs["products"], inputs["orders"]))
    columns = ["RawRowID", "InvoiceID", "LineNumber", "Status", "InvoiceDate", "CustomerID", "ProductID",
               "Quantity", "UnitPrice", "NetAmount", "f_missing_required", "f_status_class",
               "f_duplicate_class", "f_date_valid", "f_customer_matches", "f_product_matches", "f_amount_ok",
               "f_order_ref_present", "f_order_matches", "Disposition", "ReasonCode"]
    return decided.filter(F.col("RawRowID").isin(*list(raw_row_ids))).select(*columns).orderBy("RawRowID")
