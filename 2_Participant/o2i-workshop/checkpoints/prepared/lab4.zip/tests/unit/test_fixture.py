"""Code tests on the approved fixture: the whole contract, without Spark.

The fixture files in tests/fixtures hold 56 delivered rows in 48 cases, and the expected outcome of
every row. The expected results were written by hand from the business contract and validated by
the instructor. They are the oracle: never edit an expected value to make a test pass.
"""
import unittest

from o2i import config, rules
from tests import fixture_data


class FixtureContractTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.lines = fixture_data.load("fixture_invoice_lines")
        cls.outcomes = rules.evaluate_rows(cls.lines, fixture_data.load("fixture_customers"),
                                           fixture_data.load("fixture_products"), fixture_data.load("fixture_orders"))
        cls.expected = [e for e in fixture_data.load("fixture_expected_results")
                        if e["ContractVersion"] == config.CONTRACT_VERSION]

    def test_every_delivered_row_gets_exactly_one_outcome(self):
        self.assertEqual(len(self.lines), 56)
        self.assertEqual(set(self.outcomes), {row["RawRowID"] for row in self.lines})

    def test_every_row_has_the_expected_outcome(self):
        self.assertEqual(len(self.expected), len(self.lines))
        for e in self.expected:
            if e["CaseID"] in ("F36", "F37", "F38", "F39", "F40", "F41", "F42"):
                continue                                     # order reference cases: covered by the checks on Databricks
            with self.subTest(case=e["CaseID"], row=e["RawRowID"]):
                self.assertEqual(self.outcomes[e["RawRowID"]], (e["ExpectedDisposition"], e["ExpectedReason"]))

    def test_amounts_equal_the_hand_calculation(self):
        amounts = fixture_data.load("fixture_expected_amounts")
        self.assertEqual(len(amounts), 22)
        for a in amounts:
            with self.subTest(case=a["CaseID"], row=a["RawRowID"]):
                self.assertEqual(rules.tax_amount(a["NetAmount"], a["TaxRate"]), a["ExpectedTaxAmount"])
                self.assertEqual(rules.gross_amount(a["NetAmount"], a["TaxRate"]), a["ExpectedGrossAmount"])


if __name__ == "__main__":
    unittest.main()
