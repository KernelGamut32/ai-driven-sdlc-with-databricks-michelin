"""Trace delivered rows through the rules: the delivered values, one fact for each rule, the outcome.

Set TRACE_DATASET and TRACE_ROWS in lab_config.py, then run this file on Databricks. Use it to trace a
failing check to specific records. A row that this trace cannot find was lost before any rule
looked at it.
"""
import lab_config
from o2i import report, transform
from o2i.session import get_spark, output_schema


def show(value) -> str:
    return "NULL" if value is None else repr(value) if isinstance(value, str) else str(value)


def main():
    spark = get_spark()
    report.print_header(spark, output_schema(spark))
    wanted = list(lab_config.TRACE_ROWS)
    rows = transform.trace(spark, lab_config.TRACE_DATASET, wanted).collect()
    print(f"\nTrace on dataset '{lab_config.TRACE_DATASET}': {len(wanted)} rows asked for, {len(rows)} found")
    for row in rows:
        fields = row.asDict()
        facts = " | ".join(f"{name[2:]} {show(value)}" for name, value in fields.items() if name.startswith("f_"))
        print(f"\n{fields['RawRowID']}  {fields['InvoiceID']} line {show(fields['LineNumber'])}")
        print(f"  delivered  status {show(fields['Status'])}, date {show(fields['InvoiceDate'])}, "
              f"customer {show(fields['CustomerID'])}, product {show(fields['ProductID'])}")
        print(f"             quantity {show(fields['Quantity'])} x unit price {show(fields['UnitPrice'])}, "
              f"net amount {show(fields['NetAmount'])}")
        print(f"  facts      {facts}")
        print(f"  outcome    {fields['Disposition']} {fields['ReasonCode'] or ''}".rstrip())
    found = {row["RawRowID"] for row in rows}
    for raw_row_id in wanted:
        if raw_row_id not in found:
            print(f"\n{raw_row_id}  NOT IN THE RESULT: no rule decided this row. It was lost before the rules.")


if __name__ == "__main__":
    main()
