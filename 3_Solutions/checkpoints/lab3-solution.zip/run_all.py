"""The full regression suite: the code tests, then the transformation and every data-quality check.

Run this after a fix, before you call a change ready for review. The code tests need no Spark.
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import run_checks  # noqa: E402


def main():
    suite = unittest.defaultTestLoader.discover(os.path.join(ROOT, "tests"), top_level_dir=ROOT)
    outcome = unittest.TextTestRunner(stream=sys.stdout, verbosity=1).run(suite)
    bad_tests = len({getattr(test, "test_case", test).id() for test, _ in outcome.failures + outcome.errors})
    skipped = len(outcome.skipped)
    print(f"CODE TESTS: {outcome.testsRun - bad_tests - skipped} passed, {bad_tests} failed"
          + (f", {skipped} skipped" if skipped else "") + "\n")
    failed_checks = run_checks.main()
    green = bad_tests == 0 and failed_checks == 0
    print(f"REGRESSION: {'ALL GREEN' if green else 'NOT GREEN'}")


if __name__ == "__main__":
    main()
