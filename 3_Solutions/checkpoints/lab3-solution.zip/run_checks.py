"""Run the O2I transformation, write the output tables, and run every data-quality check on them.

Processes the datasets of lab_config.DATASETS. The last line says whether a check failed.
"""
import lab_config
from o2i import checks, report, transform
from o2i.session import get_spark, output_schema


def main() -> int:
    spark = get_spark()
    schema = output_schema(spark)
    report.print_header(spark, schema)
    failed = 0
    for dataset in lab_config.DATASETS:
        outputs = transform.build_outputs(spark, dataset)
        names = transform.write_outputs(outputs, schema, dataset)
        report.print_outcomes(dataset, names, transform.outcome_counts(spark, names))
        results = checks.run_checks(checks.load_context(spark, dataset, names))
        print(checks.format_results(dataset, results))
        failed += sum(1 for r in results if r.passed is False)
    print(f"\nCHECKS: {'ALL PASSED' if failed == 0 else str(failed) + ' FAILED'}")
    return failed


if __name__ == "__main__":
    main()
