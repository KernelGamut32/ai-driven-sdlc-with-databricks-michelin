"""Data-quality checks for the written outputs of the O2I transformation.

A code test asks whether a function behaves as specified. A check in this module asks whether the
tables that a run wrote satisfy the business contract. Each check reads the delivered rows and the
written output tables, and returns a CheckResult with evidence: counts, and record keys.

A check never repairs data and never changes an expected value. It reports.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import lab_config
from o2i import config, rules
from o2i.session import table_name

SAMPLE = 5


@dataclass
class CheckResult:
    name: str
    passed: Optional[bool]              # True, False, or None when the check does not apply or is not written yet
    summary: str
    evidence: List[str] = field(default_factory=list)

    @property
    def status(self) -> str:
        return {True: "PASS", False: "FAIL", None: "SKIP"}[self.passed]


@dataclass
class Context:
    """Everything a check may read for one dataset."""
    spark: object
    dataset: str
    raw: DataFrame
    customers: DataFrame
    products: DataFrame
    orders: DataFrame
    accepted: DataFrame
    exceptions: DataFrame
    expected_results: Optional[DataFrame]
    expected_amounts: Optional[DataFrame]


def load_context(spark, dataset: str, output_names: Dict[str, str]) -> Context:
    tables = config.DATASET_TABLES[dataset]

    def read(key):
        return spark.table(table_name(lab_config.INPUT_SCHEMA, tables[key])) if tables.get(key) else None
    return Context(spark, dataset, read("invoice_lines"), read("customers"), read("products"), read("orders"),
                   spark.table(output_names["accepted"]), spark.table(output_names["exceptions"]),
                   read("expected_results"), read("expected_amounts"))


def _keys(df: DataFrame, columns, limit: int = SAMPLE) -> List[str]:
    rows = df.select(*columns).orderBy(*columns).limit(limit).collect()
    return [" / ".join("NULL" if r[c] is None else str(r[c]) for c in columns) for r in rows]


def _outcomes(ctx: Context) -> DataFrame:
    """One row for each written output row: RawRowID, Disposition, ReasonCode."""
    accepted = ctx.accepted.select("RawRowID", F.lit(config.ACCEPTED).alias("Disposition"),
                                   F.lit(None).cast("string").alias("ReasonCode"))
    return accepted.unionByName(ctx.exceptions.select("RawRowID", "Disposition", "ReasonCode"))


# ---- schema and required fields ----------------------------------------------------------------------

def schema_contract(ctx: Context) -> CheckResult:
    """Both outputs have exactly the columns and types of the contract, in order."""
    problems = []
    for label, df, contract in (("accepted", ctx.accepted, config.ACCEPTED_SCHEMA),
                                ("exceptions", ctx.exceptions, config.EXCEPTIONS_SCHEMA)):
        actual = [(f.name, f.dataType.simpleString()) for f in df.schema.fields]
        if actual != list(contract):
            wanted = dict(contract)
            got = dict(actual)
            for name in [n for n, _ in contract if n not in got]:
                problems.append(f"{label}: column {name} is missing")
            for name in [n for n, _ in actual if n not in wanted]:
                problems.append(f"{label}: column {name} is not in the contract")
            for name, dtype in actual:
                if name in wanted and wanted[name] != dtype:
                    problems.append(f"{label}.{name}: type {dtype}, contract says {wanted[name]}")
            if not problems:
                problems.append(f"{label}: column order differs from the contract")
    return CheckResult("schema_contract", not problems,
                       "columns and types match the contract" if not problems else f"differences from the contract: {len(problems)}",
                       problems[:SAMPLE])


def required_fields(ctx: Context) -> CheckResult:
    """No accepted line has a NULL in a column that the contract fills for every accepted line."""
    nullable = {"TaxRate", "OrderID", "OrderLineNumber"}
    columns = [name for name, _ in config.ACCEPTED_SCHEMA if name not in nullable]
    counts = ctx.accepted.agg(*[F.sum(F.col(c).isNull().cast("int")).alias(c) for c in columns]).first()
    bad = {c: counts[c] for c in columns if counts[c]}
    evidence = [f"{c}: accepted rows with NULL: {n:,}" for c, n in bad.items()]
    return CheckResult("required_fields", not bad,
                       "no NULL in a required output column" if not bad else f"columns with NULL values: {len(bad)}",
                       evidence[:SAMPLE])


# ---- record accountability -----------------------------------------------------------------------------

def reconciliation(ctx: Context) -> CheckResult:
    """Every delivered row is in exactly one output: raw = accepted + exceptions, by RawRowID."""
    raw_n, accepted_n, exceptions_n = ctx.raw.count(), ctx.accepted.count(), ctx.exceptions.count()
    written = ctx.accepted.select("RawRowID").unionByName(ctx.exceptions.select("RawRowID"))
    lost = ctx.raw.select("RawRowID").join(written, "RawRowID", "left_anti")
    twice = written.groupBy("RawRowID").count().filter(F.col("count") > 1)
    lost_n, twice_n = lost.count(), twice.count()
    passed = raw_n == accepted_n + exceptions_n and lost_n == 0 and twice_n == 0
    summary = f"raw {raw_n:,} = accepted {accepted_n:,} + exceptions {exceptions_n:,}"
    evidence = []
    if not passed:
        summary = (f"raw {raw_n:,}, accepted {accepted_n:,} + exceptions {exceptions_n:,} = "
                   f"{accepted_n + exceptions_n:,}; rows in no output: {lost_n:,}; rows written more than once: {twice_n:,}")
        evidence = [f"in no output: {k}" for k in _keys(lost, ["RawRowID"])]
        evidence += [f"more than once: {k}" for k in _keys(twice, ["RawRowID"])]
    return CheckResult("reconciliation", passed, summary, evidence)


def amount_totals(ctx: Context) -> CheckResult:
    """For each currency: the delivered NetAmount total equals accepted plus exceptions."""
    def totals(df, name):
        currency = F.coalesce(F.col("Currency"), F.lit("(no currency)")).alias("Currency")
        return df.groupBy(currency).agg(F.sum("NetAmount").alias(name))
    joined = (totals(ctx.raw, "raw").join(totals(ctx.accepted, "accepted"), "Currency", "full")
              .join(totals(ctx.exceptions, "exceptions"), "Currency", "full"))
    zero = F.lit(0).cast("decimal(18,2)")
    diff = joined.withColumn("difference", F.coalesce(F.col("raw"), zero) - F.coalesce(F.col("accepted"), zero)
                             - F.coalesce(F.col("exceptions"), zero)).filter(F.col("difference") != 0)
    rows = diff.orderBy("Currency").collect()
    evidence = [f"{r['Currency']}: delivered minus written = {r['difference']}" for r in rows]
    return CheckResult("amount_totals", not rows,
                       "delivered totals equal written totals in every currency" if not rows
                       else f"currencies whose totals differ: {len(rows)}", evidence[:SAMPLE])


# ---- uniqueness and replay -----------------------------------------------------------------------------

def unique_grain(ctx: Context) -> CheckResult:
    """The accepted output has one row for each InvoiceID and LineNumber."""
    duplicated = ctx.accepted.groupBy(*config.GRAIN).count().filter(F.col("count") > 1)
    n = duplicated.count()
    return CheckResult("unique_grain", n == 0,
                       "one accepted row for each InvoiceID and LineNumber" if n == 0
                       else f"keys with more than one accepted row: {n:,}",
                       _keys(duplicated, list(config.GRAIN)) if n else [])


def conflicts_held(ctx: Context) -> CheckResult:
    """No key that was delivered as posted with different business content is in the accepted output."""
    content_columns = [c for c in ctx.raw.columns if c not in config.TECHNICAL_COLUMNS]
    content = F.sha2(F.concat_ws("\u001f", *[F.coalesce(F.col(c).cast("string"), F.lit("\u0000"))
                                             for c in content_columns]), 256)
    posted = ctx.raw.filter(F.upper(F.trim(F.col("Status"))) == "POSTED").withColumn("content", content)
    conflict_keys = (posted.groupBy(*config.GRAIN).agg(F.countDistinct("content").alias("versions"))
                     .filter(F.col("versions") > 1).select(*config.GRAIN))
    accepted_conflicts = ctx.accepted.join(conflict_keys, list(config.GRAIN), "left_semi")
    n_keys, n = conflict_keys.count(), accepted_conflicts.count()
    return CheckResult("conflicts_held", n == 0,
                       f"conflicting keys delivered: {n_keys:,}; none of them accepted" if n == 0
                       else f"conflicting keys delivered: {n_keys:,}; accepted rows of these keys: {n:,}",
                       _keys(accepted_conflicts, ["RawRowID", *config.GRAIN]) if n else [])


# ---- relationships and joins ---------------------------------------------------------------------------

def referential_integrity(ctx: Context) -> CheckResult:
    """Every accepted CustomerID and ProductID has exactly one row in its master table."""
    evidence, bad_total = [], 0
    for key, master in (("CustomerID", ctx.customers), ("ProductID", ctx.products)):
        master_rows = master.groupBy(key).agg(F.count(F.lit(1)).alias("master_rows"))
        bad = (ctx.accepted.join(master_rows, key, "left")
               .filter(F.coalesce(F.col("master_rows"), F.lit(0)) != 1))
        n = bad.count()
        bad_total += n
        if n:
            evidence.append(f"{key}: accepted rows without exactly one master row: {n:,}, for example "
                            + ", ".join(_keys(bad, ["RawRowID", key], 3)))
    return CheckResult("referential_integrity", bad_total == 0,
                       "every accepted key has exactly one master row" if bad_total == 0
                       else f"accepted rows with an unknown or ambiguous key: {bad_total:,}", evidence)



# ---- business rules ------------------------------------------------------------------------------------

def status_rule(ctx: Context) -> CheckResult:
    """Only posted lines are accepted, and no posted line is turned away because of its status."""
    raw_status = ctx.raw.select("RawRowID", F.upper(F.trim(F.col("Status"))).alias("status"))
    not_posted = (ctx.accepted.join(raw_status, "RawRowID", "left")
                  .filter(F.col("status").isNull() | (F.col("status") != "POSTED")))
    turned_away = ctx.exceptions.filter(F.col("ReasonCode").isin("NOT_POSTED", "UNEXPECTED_STATUS")
                                        & (F.upper(F.trim(F.col("Status"))) == "POSTED"))
    a, b = not_posted.count(), turned_away.count()
    evidence = [f"accepted, not posted: {k}" for k in _keys(not_posted, ["RawRowID", "status"], 3)] if a else []
    if b:
        values = turned_away.groupBy("Status").count().orderBy(F.desc("count")).limit(6).collect()
        evidence.append("posted, turned away, by delivered status: "
                        + ", ".join(f"'{r['Status']}' ({r['count']:,})" for r in values))
        evidence += [f"posted, turned away: {k}" for k in _keys(turned_away, ["RawRowID", "ReasonCode"], 3)]
    return CheckResult("status_rule", a == 0 and b == 0,
                       "only posted lines accepted, no posted line turned away for its status" if a + b == 0
                       else f"accepted rows that are not posted: {a:,}; posted rows turned away for their status: {b:,}",
                       evidence)


def signed_amounts(ctx: Context) -> CheckResult:
    """Signs and amounts survive: one sign per accepted line, NetAmount as delivered, and rule R7 both ways."""
    sign_differs = ctx.accepted.filter((F.signum("Quantity") != F.signum("NetAmount"))
                                       | (F.signum("NetAmount") != F.signum("GrossAmount")))
    changed = (ctx.accepted.select("RawRowID", F.col("NetAmount").alias("written"))
               .join(ctx.raw.select("RawRowID", F.col("NetAmount").alias("delivered")), "RawRowID")
               .filter(F.col("written") != F.col("delivered")))
    matches = F.col("NetAmount") == F.round(F.col("Quantity") * F.col("UnitPrice"), 2)
    wrongly_held = ctx.exceptions.filter((F.col("ReasonCode") == "AMOUNT_MISMATCH") & matches)
    a, b, c = sign_differs.count(), changed.count(), wrongly_held.count()
    credits = ctx.accepted.filter(F.col("NetAmount") < 0).count()
    evidence = []
    if a:
        evidence += [f"accepted with mixed signs: {k}" for k in _keys(sign_differs, ["RawRowID", "Quantity", "NetAmount"], 3)]
    if b:
        evidence += [f"NetAmount changed: {k}" for k in _keys(changed, ["RawRowID", "delivered", "written"], 3)]
    if c:
        evidence += [f"held as AMOUNT_MISMATCH although the amount matches: {k}"
                     for k in _keys(wrongly_held, ["RawRowID", "Quantity", "UnitPrice", "NetAmount"], 3)]
    return CheckResult("signed_amounts", a + b + c == 0,
                       f"signs and amounts intact; accepted credit lines: {credits:,}" if a + b + c == 0
                       else f"accepted rows with mixed signs: {a:,}; changed amounts: {b:,}; "
                            f"matching amounts held as AMOUNT_MISMATCH: {c:,}; accepted credit lines: {credits:,}",
                       evidence)


# ---- the fixture and the expected results --------------------------------------------------------------

def expected_outcomes(ctx: Context) -> CheckResult:
    """Each row has the outcome that the validated answer set expects, for the contract version of the code."""
    if ctx.expected_results is None:
        return CheckResult("expected_outcomes", None, "this dataset has no expected results")
    expected = ctx.expected_results.filter(F.col("ContractVersion") == config.CONTRACT_VERSION)
    actual = _outcomes(ctx).select("RawRowID", F.col("Disposition").alias("got_disposition"),
                                   F.col("ReasonCode").alias("got_reason"))
    compared = expected.join(actual, "RawRowID", "full")
    differs = compared.filter(
        F.col("ExpectedDisposition").isNull() | F.col("got_disposition").isNull()
        | (F.col("ExpectedDisposition") != F.col("got_disposition"))
        | (F.coalesce(F.col("ExpectedReason"), F.lit("")) != F.coalesce(F.col("got_reason"), F.lit(""))))
    rows = differs.orderBy("RawRowID").collect()
    evidence = []
    for r in rows[:SAMPLE]:
        want = f"{r['ExpectedDisposition']} {r['ExpectedReason'] or ''}".strip()
        got = "in no output" if r["got_disposition"] is None else f"{r['got_disposition']} {r['got_reason'] or ''}".strip()
        evidence.append(f"{r['RawRowID']} ({r['CaseID']}): expected {want}, got {got}")
    total = expected.count()
    return CheckResult(f"expected_outcomes_v{config.CONTRACT_VERSION}", not rows,
                       f"all {total:,} expected outcomes match" if not rows
                       else f"rows that differ from the expected outcome: {len(rows):,} of {total:,}", evidence)


def expected_amounts(ctx: Context) -> CheckResult:
    """TaxAmount and GrossAmount of accepted fixture lines equal the hand-calculated amounts."""
    if ctx.expected_amounts is None:
        return CheckResult("expected_amounts", None, "this dataset has no expected amounts")
    compared = ctx.accepted.select("RawRowID", "TaxAmount", "GrossAmount").join(ctx.expected_amounts, "RawRowID")
    differs = compared.filter(F.col("TaxAmount").isNull() | F.col("GrossAmount").isNull()
                              | (F.col("TaxAmount") != F.col("ExpectedTaxAmount"))
                              | (F.col("GrossAmount") != F.col("ExpectedGrossAmount")))
    rows = differs.orderBy("RawRowID").collect()
    evidence = [f"{r['RawRowID']} ({r['CaseID']}): expected tax {r['ExpectedTaxAmount']} gross {r['ExpectedGrossAmount']}, "
                f"got tax {r['TaxAmount']} gross {r['GrossAmount']}" for r in rows[:SAMPLE]]
    total = compared.count()
    return CheckResult("expected_amounts", not rows,
                       f"all {total:,} compared amounts match" if not rows
                       else f"accepted fixture lines with a wrong amount: {len(rows):,} of {total:,}", evidence)


def spec_agreement(ctx: Context) -> CheckResult:
    """On the fixture, the Spark result equals the plain-Python rules (o2i.rules), row by row."""
    if ctx.dataset != "fixture":
        return CheckResult("spec_agreement", None, "runs on the fixture only: it collects every row")
    raw_rows = [r.asDict() for r in ctx.raw.collect()]
    spec = rules.evaluate_rows(raw_rows, [r.asDict() for r in ctx.customers.collect()],
                               [r.asDict() for r in ctx.products.collect()])
    got = {r["RawRowID"]: (r["Disposition"], r["ReasonCode"]) for r in _outcomes(ctx).collect()}
    evidence = []
    for rid in sorted(spec):
        if got.get(rid) != spec[rid]:
            evidence.append(f"{rid}: rules say {spec[rid]}, Spark wrote {got.get(rid, 'no row')}")
    by_id = {r["RawRowID"]: r for r in raw_rows}
    for r in ctx.accepted.select("RawRowID", "TaxAmount", "GrossAmount").collect():
        row = by_id[r["RawRowID"]]
        try:
            want = (rules.tax_amount(row["NetAmount"], row["TaxRate"]), rules.gross_amount(row["NetAmount"], row["TaxRate"]))
        except Exception as error:                      # a rule that cannot handle a delivered value
            want = f"{type(error).__name__}: {error}"
        if want != (r["TaxAmount"], r["GrossAmount"]):
            evidence.append(f"{r['RawRowID']}: rules say tax and gross {want}, "
                            f"Spark wrote ({r['TaxAmount']}, {r['GrossAmount']})")
    return CheckResult("spec_agreement", not evidence,
                       f"Spark and the plain-Python rules agree on all {len(spec):,} fixture rows" if not evidence
                       else f"points where Spark and the plain-Python rules disagree: {len(evidence):,}", evidence[:SAMPLE])


# ---- running the checks --------------------------------------------------------------------------------

CHECKS: List[Callable[[Context], CheckResult]] = [
    schema_contract, required_fields, reconciliation, amount_totals, unique_grain, conflicts_held,
    referential_integrity, status_rule, signed_amounts,
    expected_outcomes, expected_amounts, spec_agreement,
]


def run_checks(ctx: Context) -> List[CheckResult]:
    """Run every check. One check never stops the others.

    A check that is not written yet reports SKIP. A check that raises an error reports FAIL with the
    error: a check that cannot run has not shown anything.
    """
    results = []
    for check in CHECKS:
        try:
            results.append(check(ctx))
        except NotImplementedError as todo:
            results.append(CheckResult(check.__name__, None, f"TODO: {todo}"))
        except Exception as error:
            message = (str(error).strip().splitlines() or [""])[0][:160]
            results.append(CheckResult(check.__name__, False, f"the check raised {type(error).__name__}: {message}"))
    return results


def format_results(dataset: str, results: List[CheckResult]) -> str:
    lines = [f"Data-quality checks on dataset '{dataset}'"]
    for r in results:
        lines.append(f"  {r.status:4s}  {r.name:26s} {r.summary}")
        lines += [f"          {e}" for e in r.evidence]
    failed = sum(1 for r in results if r.passed is False)
    skipped = sum(1 for r in results if r.passed is None)
    passed = sum(1 for r in results if r.passed)
    lines.append(f"  passed {passed}, failed {failed}, skipped {skipped}")
    return "\n".join(lines)
