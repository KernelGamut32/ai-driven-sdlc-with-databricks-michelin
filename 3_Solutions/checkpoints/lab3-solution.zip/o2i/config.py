"""Names and constants shared by the rules, the transformation, and the checks.

This module imports nothing from Spark, so local tests can use it.
"""
from __future__ import annotations

CONTRACT_VERSION = "1.0"

# Fields that rule R1 requires on every delivered invoice line.
REQUIRED_FIELDS = ("InvoiceID", "LineNumber", "InvoiceDate", "Status", "CustomerID", "ProductID",
                   "Quantity", "UnitPrice", "NetAmount", "Currency")

# Columns that describe the delivery, not the business content of a line (rule R3).
TECHNICAL_COLUMNS = ("RawRowID", "LoadBatchID", "IngestedAt")

GRAIN = ("InvoiceID", "LineNumber")

ACCEPTED, QUARANTINED, EXCLUDED = "ACCEPTED", "QUARANTINED", "EXCLUDED"

# A reason code decides the disposition. Every other reason code means QUARANTINED.
EXCLUDED_REASONS = ("NOT_POSTED", "EXACT_REPLAY")

REASONS = ("MISSING_REQUIRED_FIELD", "NOT_POSTED", "UNEXPECTED_STATUS", "CONFLICTING_DUPLICATE",
           "EXACT_REPLAY", "INVALID_DATE", "UNKNOWN_CUSTOMER", "AMBIGUOUS_CUSTOMER", "UNKNOWN_PRODUCT",
           "AMBIGUOUS_PRODUCT", "AMOUNT_MISMATCH")

# Table names inside the input schema, for each dataset that the entry points can process.
DATASET_TABLES = {
    "fixture": {"invoice_lines": "fixture_invoice_lines", "customers": "fixture_customers",
                "products": "fixture_products", "orders": "fixture_orders",
                "expected_results": "fixture_expected_results", "expected_amounts": "fixture_expected_amounts"},
    "training": {"invoice_lines": "invoice_lines", "customers": "customers", "products": "products",
                 "orders": "orders", "expected_results": None, "expected_amounts": None},
    "challenge": {"invoice_lines": "challenge_invoice_lines", "customers": "customers", "products": "products",
                  "orders": "orders", "expected_results": "challenge_expected_results", "expected_amounts": None},
}

# The output contract: column name and Spark type, in order.
ACCEPTED_SCHEMA = (
    ("RawRowID", "string"), ("InvoiceID", "string"), ("LineNumber", "int"), ("InvoiceDate", "date"),
    ("DocumentType", "string"), ("CustomerID", "string"), ("CustomerName", "string"), ("Segment", "string"),
    ("Country", "string"), ("Region", "string"), ("ProductID", "string"), ("ProductName", "string"),
    ("ProductLine", "string"), ("OrderID", "string"), ("OrderLineNumber", "int"),
    ("Quantity", "decimal(12,3)"), ("UnitPrice", "decimal(18,4)"), ("NetAmount", "decimal(18,2)"),
    ("TaxRate", "decimal(6,4)"), ("TaxAmount", "decimal(18,2)"), ("GrossAmount", "decimal(18,2)"),
    ("Currency", "string"), ("LoadBatchID", "string"),
)
EXCEPTIONS_SCHEMA = (
    ("RawRowID", "string"), ("InvoiceID", "string"), ("LineNumber", "int"), ("Disposition", "string"),
    ("ReasonCode", "string"), ("Status", "string"), ("InvoiceDate", "string"), ("DocumentType", "string"),
    ("CustomerID", "string"), ("ProductID", "string"), ("OrderID", "string"), ("OrderLineNumber", "int"),
    ("Quantity", "decimal(12,3)"), ("UnitPrice", "decimal(18,4)"), ("NetAmount", "decimal(18,2)"),
    ("TaxRate", "decimal(6,4)"), ("Currency", "string"), ("LoadBatchID", "string"),
)
