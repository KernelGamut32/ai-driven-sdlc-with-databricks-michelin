# Change request CR-2026-041: validate the order reference of every invoice line

Requested by the sales analytics squad. Applies to the business contract, version 1.0. When this
change is accepted, the contract becomes version 1.1.

## Why

The squad compares invoiced revenue with ordered revenue. An invoice line whose order line cannot
be found makes that comparison wrong, and nobody notices. From now on such a line must be reported,
not accepted.

## The new rule

**R8 Order reference.** Rule R8 is checked after rule R7. A line passes when `OrderID` and
`OrderLineNumber` are present and match exactly one row of the `orders` table.

| Situation | Disposition | Reason code |
|---|---|---|
| `OrderID` is NULL or blank, or `OrderLineNumber` is NULL | `QUARANTINED` | `MISSING_ORDER_REF` |
| No row of `orders` has this `OrderID` and `OrderLineNumber` | `QUARANTINED` | `UNKNOWN_ORDER_REF` |
| More than one row of `orders` has this `OrderID` and `OrderLineNumber` | `QUARANTINED` | `AMBIGUOUS_ORDER_REF` |

## What does not change

- Rules R1 to R7, and their order. A line that fails an earlier rule keeps its earlier reason.
- The columns and types of both outputs.
- Credits. A valid posted credit line keeps its signed amounts and is accepted when every rule
  passes, including R8.
- Accountability. Every delivered row still ends in exactly one disposition.

## What the rule does not do

- It does not compare quantity, price, customer, product, or order status with the order line.
  A credit has a negative quantity and its order line has a positive one: that is not a failure.
- It does not guess. A line that matches an order by `OrderID` alone does not pass.
- It does not repair. A missing reference is reported, never filled.

## Acceptance

The change is ready for review when all of this is shown:

1. The expected results for contract version 1.1 match, for the fixture and for the challenge batch.
2. A test or check failed before the change and passes after it. Every earlier test and check still passes.
3. No delivered row is lost or multiplied: delivered rows = accepted rows + exception rows.
4. The revision that ran on Databricks is the revision that was reviewed.
5. The developer explains the change, its evidence, and its limits without reading an AI answer.

## Test data

- Fixture: cases F36 to F42 change with this rule. The expected results table has both versions.
- Challenge batch: 191 delivered rows in 16 named cases (C01 to C16), in the table
  `challenge_invoice_lines`, with expected results in `challenge_expected_results`. The batch
  includes unknown, missing, and ambiguous order references, an exact replay, and valid signed credits.
