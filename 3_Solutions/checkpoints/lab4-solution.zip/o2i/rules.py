"""The business contract in plain Python.

No Spark and no third-party package: these functions run anywhere, and the local tests exercise
them in milliseconds. The Spark transformation (o2i.transform) implements the same rules for full
tables. The data-quality check spec_agreement proves on the fixture that both agree, row by row.

Money is decimal.Decimal, never float. Rounding is half up, which is the rounding of Spark's round().
"""
from __future__ import annotations

import datetime
import re
from collections import Counter, defaultdict
from decimal import ROUND_HALF_UP, Decimal
from typing import Dict, Iterable, List, Optional, Tuple

from o2i import config

CENT = Decimal("0.01")
_ISO_DATE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")


# ---- R1: required fields -------------------------------------------------------------------------

def is_blank(value) -> bool:
    """True for a missing value: None, or text that is empty after trimming."""
    return value is None or (isinstance(value, str) and value.strip() == "")


def has_missing_required(row: dict) -> bool:
    """True when at least one required field of the invoice line is missing."""
    return any(is_blank(row.get(field)) for field in config.REQUIRED_FIELDS)


# ---- R2: status ----------------------------------------------------------------------------------

def normalize_status(raw: Optional[str]) -> Optional[str]:
    """Comparison form of a delivered status: trimmed and upper case. The raw value is never rewritten."""
    if raw is None:
        return None
    return raw.strip().upper()


def classify_status(raw: Optional[str]) -> str:
    """Return POSTED, NOT_POSTED (draft or cancelled), or UNEXPECTED (any other value, or no value)."""
    status = normalize_status(raw)
    if status == "POSTED":
        return "POSTED"
    if status in ("DRAFT", "CANCELLED"):
        return "NOT_POSTED"
    return "UNEXPECTED"


# ---- R3: line identity ---------------------------------------------------------------------------

def business_content(row: dict) -> tuple:
    """The values that make two deliveries of one invoice line identical: all but the technical columns."""
    return tuple((name, row[name]) for name in sorted(row) if name not in config.TECHNICAL_COLUMNS)


def duplicate_classes(rows: List[dict]) -> Dict[str, str]:
    """Classify the rows that share one InvoiceID and LineNumber. Returns RawRowID -> class.

    UNIQUE        the key was delivered once
    REPLAY_FIRST  identical deliveries: the row with the lowest RawRowID continues
    REPLAY_EXTRA  identical deliveries: every other row is a documented replay
    CONFLICT      deliveries that differ: no row may be chosen, all are held
    """
    if len(rows) == 1:
        return {rows[0]["RawRowID"]: "UNIQUE"}
    if len({business_content(r) for r in rows}) > 1:
        return {r["RawRowID"]: "CONFLICT" for r in rows}
    first = min(r["RawRowID"] for r in rows)
    return {r["RawRowID"]: ("REPLAY_FIRST" if r["RawRowID"] == first else "REPLAY_EXTRA") for r in rows}


# ---- R4: invoice date ----------------------------------------------------------------------------

def is_valid_iso_date(text: Optional[str]) -> bool:
    """True only for a real calendar date written exactly as yyyy-MM-dd."""
    if not isinstance(text, str):
        return False
    match = _ISO_DATE.match(text)
    if not match:
        return False
    try:
        datetime.date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    except ValueError:
        return False
    return True


# ---- R7 and the derived amounts ------------------------------------------------------------------

def _as_decimal(value, name: str) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return Decimal(value)
    raise TypeError(f"{name} must be a Decimal, not {type(value).__name__}: money is never a float")


def round_half_up(value: Decimal) -> Decimal:
    """Round to two decimals, half away from zero: 0.165 becomes 0.17, and -0.165 becomes -0.17."""
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def expected_net_amount(quantity: Decimal, unit_price: Decimal) -> Decimal:
    """Quantity times unit price, rounded half up. The sign of the quantity is the sign of the result."""
    return round_half_up(_as_decimal(quantity, "quantity") * _as_decimal(unit_price, "unit_price"))


def amount_matches(quantity, unit_price, net_amount) -> bool:
    """Rule R7: the delivered NetAmount equals quantity times unit price. A missing value never matches."""
    if quantity is None or unit_price is None or net_amount is None:
        return False
    return expected_net_amount(quantity, unit_price) == _as_decimal(net_amount, "net_amount")


def tax_amount(net_amount: Decimal, tax_rate: Optional[Decimal]) -> Decimal:
    """Tax of one line, rounded half up. No tax rate means that no tax applies: the result is 0.00."""
    net = _as_decimal(net_amount, "net_amount")
    if tax_rate is None:
        return Decimal("0.00")
    return round_half_up(net * _as_decimal(tax_rate, "tax_rate"))


def gross_amount(net_amount: Decimal, tax_rate: Optional[Decimal]) -> Decimal:
    """Net amount plus tax. A credit stays negative: -3.00 at 5.5 percent is -3.17."""
    net = _as_decimal(net_amount, "net_amount")
    return net + tax_amount(net, tax_rate)


# ---- the decision: one outcome for each delivered row --------------------------------------------

def decide_disposition(*, missing_required: bool, status_class: str, duplicate_class: Optional[str],
                       date_valid: bool, customer_matches: int, product_matches: int, amount_ok: bool,
                       order_ref_present: bool, order_matches: int) -> Tuple[str, Optional[str]]:
    """Return (disposition, reason code). The first rule that fails decides, in the order of the contract."""
    if missing_required:
        reason = "MISSING_REQUIRED_FIELD"                    # R1
    elif status_class == "NOT_POSTED":
        reason = "NOT_POSTED"                                # R2
    elif status_class != "POSTED":
        reason = "UNEXPECTED_STATUS"                         # R2
    elif duplicate_class == "CONFLICT":
        reason = "CONFLICTING_DUPLICATE"                     # R3
    elif duplicate_class == "REPLAY_EXTRA":
        reason = "EXACT_REPLAY"                              # R3
    elif not date_valid:
        reason = "INVALID_DATE"                              # R4
    elif customer_matches == 0:
        reason = "UNKNOWN_CUSTOMER"                          # R5
    elif customer_matches > 1:
        reason = "AMBIGUOUS_CUSTOMER"                        # R5
    elif product_matches == 0:
        reason = "UNKNOWN_PRODUCT"                           # R6
    elif product_matches > 1:
        reason = "AMBIGUOUS_PRODUCT"                         # R6
    elif not amount_ok:
        reason = "AMOUNT_MISMATCH"                           # R7
    elif not order_ref_present:
        reason = "MISSING_ORDER_REF"                         # R8
    elif order_matches == 0:
        reason = "UNKNOWN_ORDER_REF"                         # R8
    elif order_matches > 1:
        reason = "AMBIGUOUS_ORDER_REF"                       # R8
    else:
        return config.ACCEPTED, None
    disposition = config.EXCLUDED if reason in config.EXCLUDED_REASONS else config.QUARANTINED
    return disposition, reason


# ---- the whole contract for a small set of rows --------------------------------------------------

def evaluate_rows(invoice_rows: Iterable[dict], customers: Iterable[dict], products: Iterable[dict],
                  orders: Iterable[dict]) -> Dict[str, Tuple[str, Optional[str]]]:
    """Apply the contract to delivered rows held in memory. Returns RawRowID -> (disposition, reason).

    This is the reference for small, hand-verifiable data such as the fixture. It is not meant for
    full tables: that is the job of the Spark transformation.
    """
    invoice_rows = list(invoice_rows)
    customer_rows = Counter(c["CustomerID"] for c in customers)
    product_rows = Counter(p["ProductID"] for p in products)
    order_rows = Counter((o["OrderID"], o["OrderLineNumber"]) for o in orders)

    # R3 looks only at rows that passed R1 and R2.
    groups = defaultdict(list)
    for row in invoice_rows:
        if not has_missing_required(row) and classify_status(row["Status"]) == "POSTED":
            groups[(row["InvoiceID"], row["LineNumber"])].append(row)
    duplicate_class = {}
    for rows in groups.values():
        duplicate_class.update(duplicate_classes(rows))

    outcomes = {}
    for row in invoice_rows:
        order_ref_present = not is_blank(row["OrderID"]) and row["OrderLineNumber"] is not None
        outcomes[row["RawRowID"]] = decide_disposition(
            missing_required=has_missing_required(row),
            status_class=classify_status(row["Status"]),
            duplicate_class=duplicate_class.get(row["RawRowID"]),
            date_valid=is_valid_iso_date(row["InvoiceDate"]),
            customer_matches=customer_rows.get(row["CustomerID"], 0),
            product_matches=product_rows.get(row["ProductID"], 0),
            amount_ok=amount_matches(row["Quantity"], row["UnitPrice"], row["NetAmount"]),
            order_ref_present=order_ref_present,
            order_matches=order_rows.get((row["OrderID"], row["OrderLineNumber"]), 0),
        )
    return outcomes
